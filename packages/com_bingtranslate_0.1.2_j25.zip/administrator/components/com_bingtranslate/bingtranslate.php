<?php
/**
 * Joomla! component BingTranslate
 *
 * @author Yireo
 * @package BingTranslate
 * @copyright Copyright 2011
 * @license GNU Public License
 * @link http://www.yireo.com/
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Require the base controller
require_once (JPATH_COMPONENT.DS.'controller.php');
$controller	= new BingTranslateController( );

// Perform the Request task
$controller->execute(JRequest::getCmd('task'));
$controller->redirect();

