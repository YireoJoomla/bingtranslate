/*
 * Joomla! component - Bing Translate
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright 2011
 * @license GNU Public License
 * @link http://www.yireo.com
 */

function doBingTranslate(editor, language, button) 
{
    button.className = 'bingtranslate-loading';

    // Support for Joomla! 1.6 languages
    if(jformLanguage = document.getElementById('jform_language')) {
        language = jformLanguage.value;
    }

    // Support for JoomFish
    if(languageId = document.getElementById('language_id')) {
        language = 'joomfish' + languageId.value;
    }

    // Do not continue if no language was detected
    if(language == '') {
        button.className = 'bingtranslate';
        alert('Failed to detect which language to translate to');
        return false;
    }

    // Fetch the text and try to translate it
    var textfield = document.getElementById(editor);
    var originalText = textfield.value;

    // Detect whether the text is empty
    if(originalText == '') {
        button.className = 'bingtranslate';
        alert('No text to translate');
        return false;
    }

    // Perform the POST
    var postdata = {text:originalText, to:language}; // @todo: Add-in a JToken
    var url = 'index.php?option=com_bingtranslate&task=translate';
    jQuery.ajax({
        type: 'POST',
        url: url,
        data: postdata,
        success: function(data){
            newText = data.text;
            button.className = 'bingtranslate';
            if(data.code == 0) {
                alert(newText);
            } 
            if(data.code == 1 && newText != originalText) {
                textfield.value = newText;
                if(tinyMCE) {
                    tinyMCE.execInstanceCommand(editor, 'mceSetContent', null, newText);
                }
            }
        },
        dataType: 'json'
    });

    return false;
}

