<?php
/**
 * Joomla! component Bing Translate
 *
 * @author Yireo
 * @copyright Copyright 2011
 * @license GNU Public License
 * @link http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// Import the parent controller 
jimport( 'joomla.application.component.controller' );


class BingTranslateController extends JController
{
    /**
     * Display task
     *
     * @access public
     * @param null
     * @return null
     */
    public function display()
    {
        JToolBarHelper::preferences('com_bingtranslate', 600, 800);
    }

    /**
     * Translate task
     *
     * @access public
     * @param null
     * @return null
     */
    public function translate()
    {
        // Get the language from request
        $text = JRequest::getVar('text', null, null, null, JREQUEST_ALLOWRAW);
        $toLang = JRequest::getCmd('to');
        $fromLang = JRequest::getCmd('from');

        // Detect JoomFish languages
        if(preg_match('/joomfish([0-9\-]+)/', $toLang)) {

            $languageId = preg_replace('/([^0-9]+)/', '', $toLang);
            $toLang = null;

            $db = JFactory::getDBO();
            if(self::isJoomla15()) {
                $db->setQuery('SELECT shortcode FROM #__languages WHERE id='.$languageId);
                $toLang = $db->loadResult();
            } else {
                $query = $db->getQuery(true);
                $query->select('*')->from('#__languages')->where('published=1')->order('ordering ASC');
                $db->setQuery($query);
                $languages = $db->loadObjectList();
                if(!empty($languages)) {
                    foreach($languages as $language) {
                        if(isset($language->id) && $language->id == $languageId) {
                            $toLang = $language->shortcode; 
                            break;
                        } elseif(isset($language->lang_id) && $language->lang_id == $languageId) {
                            $toLang = $language->lang_code; 
                            break;
                        }
                    }
                }
            }
        }

        // Parse the language
        $toLang = preg_replace('/-([a-zA-Z0-9]+)$/', '', $toLang);
        $fromLang = preg_replace('/-([a-zA-Z0-9]+)$/', '', $fromLang);

        // Get the API-key
        $params = JComponentHelper::getParams('com_bingtranslate');
        $api_id = $params->get('api_id');

        // Sanity checks
        if(empty($api_id)) $this->response(JText::_('BingTranslate API-key is not configured'), false);
        if(empty($text)) $this->response(JText::_('No text to translate'), false);

        // Detect the language
        if(empty($fromLang)) {
            $result = $this->getCurlDetect($text);
            if(empty($result)) $this->response(JText::_('No response from Bing'), false);
            if(!preg_match('/^</', $result)) $this->response(JText::_('Not an XML-result'), false);

            // Parse the XML-code
            $xml = new SimpleXMLElement($result);
            if(is_object($xml)) {
                $string = (string)$xml;
                if(!empty($string)) {
                    $fromLang = $string;
                }
            }
        }

        if(empty($fromLang)) $this->response(JText::_('Failed to detect source-language'), false);
        if(empty($toLang)) $this->response(JText::_('Failed to detect destination-language'), false);

        $result = $this->getCurlTranslate($text, $toLang, $fromLang);
        if(empty($result)) $this->response(JText::_('No response from Bing'), false);
        if(!preg_match('/^</', $result)) $this->response(JText::_('Not an XML-result'), false);

        $xml = new SimpleXMLElement($result);
        if(is_object($xml)) {
            $string = (string)$xml;
            if(!empty($string)) {
                $this->response($string);
            }
        }

        $this->response(JText::_('Unknown BingTranslate error: ', $result), false);
    }

    /*
     * Helper method to send a response 
     *
     * @access protected
     * @param string $text
     * @param bool $success
     * @return null
     */
    protected function response($text, $success = true)
    {
        $response = array('text' => $text, 'code' => (int)$success);
        print json_encode($response);
        $application = JFactory::getApplication();
        $application->close();
    }
    
    /*
     * Helper method to get a CURL-response 
     *
     * @access protected
     * @param string $text
     * @return string
     */
    protected function getCurlDetect($text)
    {
        $params = JComponentHelper::getParams('com_bingtranslate');
        $api_id = $params->get('api_id');
        $fields = array(
            'appId' => $api_id,
            'text' => $text,
        );
        return $this->getCurlResponse('Detect', $fields);
    }

    /*
     * Helper method to get a CURL-response 
     * 
     * @access protected
     * @param string $text
     * @param string $toLang
     * @param string $fromLang
     * @return string
     * @link http://msdn.microsoft.com/en-us/library/ff512406.aspx
     */
    protected function getCurlTranslate($text, $toLang, $fromLang)
    {
        $params = JComponentHelper::getParams('com_bingtranslate');
        $api_id = $params->get('api_id');
        $fields = array(
            'appId' => $api_id,
            'text' => $text,
            'to' => $toLang,
            'from' => $fromLang,
            'contentType' => 'text/html',
        );
        return $this->getCurlResponse('Translate', $fields);
    }

    /*
     * Helper method to get a CURL-response 
     *
     * @access protected
     * @param string $task
     * @param array $fields
     * @return string
     */
    protected function getCurlResponse($task, $fields)
    {
        $url = 'http://api.microsofttranslator.com/v2/Http.svc/'.$task;
        $url .= '?'.http_build_query($fields);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        return $result;
    }

    /*
     * Helper method to check for Joomla! 1.5
     *
     * @access protected
     * @param null
     * @return bool
     */
    protected function isJoomla15()
    {
        JLoader::import( 'joomla.version' );
        $version = new JVersion();
        if(version_compare( $version->RELEASE, '1.5', 'eq')) {
            return true;
        }
        return false;
    }
}
