<?php
/*
 * Joomla! Editor Button Plugin - Bing Translate
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * Bing Translate Editor Button Plugin
 */
class plgButtonBingTranslate extends JPlugin
{
    /**
     * Method to display the button
     *
     * @param string $name
     */
    public function onDisplay( $name )
    {
        // Add the proper JavaScript to this document
        $document = JFactory::getDocument();
        $document->addScript(JURI::base().'../media/com_bingtranslate/js/jquery.js');
        $document->addScript(JURI::base().'../media/com_bingtranslate/js/editor-xtd.js');
		$document->addScriptDeclaration("jQuery.noConflict();\n");
        $document->addStyleSheet(JURI::base().'../media/com_bingtranslate/css/editor-xtd.css');

        // Detect the language
        $lang = null;

        // Construct the button
		$button = new JObject();
		$button->set('modal', false);
		$button->set('onclick', 'javascript:doBingTranslate(\''.$name.'\', \''.$lang.'\', this);return false;');
		$button->set('text', 'Bing Translate');
		$button->set('name', 'bingtranslate');
		$button->set('link', '#');

		return $button;
    }
}
