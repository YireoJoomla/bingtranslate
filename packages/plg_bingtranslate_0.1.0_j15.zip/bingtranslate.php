<?php
/*
 * Joomla! Editor Button Plugin - Bing Translate
 *
 * @author Yireo (info@yireo.com)
 * @copyright Copyright 2011
 * @license GNU Public License
 * @link http://www.yireo.com
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.plugin.plugin' );

/**
 * Bing Translate Editor Button Plugin
 */
class plgButtonBingTranslate extends JPlugin
{
    /**
     * Method to display the button
     *
     * @param string $name
     */
    public function onDisplay( $name )
    {
        // Add the proper JavaScript to this document
        $document = JFactory::getDocument();
        $document->addScript('/media/com_bingtranslate/js/jquery.js');
        $document->addScript('/media/com_bingtranslate/js/editor-xtd.js');
		$document->addScriptDeclaration("jQuery.noConflict();\n");

        // Detect the language
        $lang = null;

        // Construct the button
		$button = new JObject();
		$button->set('modal', false);
		$button->set('onclick', 'javascript:doBingTranslate(\''.$name.'\', \''.$lang.'\');return false;');
		$button->set('text', 'Bing Translate');
		$button->set('name', 'readmore');
		$button->set('link', '#');

		return $button;
    }
}
