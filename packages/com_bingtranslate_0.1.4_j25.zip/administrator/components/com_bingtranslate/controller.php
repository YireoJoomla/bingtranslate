<?php
/**
 * Joomla! component Bing Translate
 *
 * @author Yireo
 * @copyright Copyright 2012
 * @license GNU Public License
 * @link http://www.yireo.com/
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// Import the parent controller 
require_once JPATH_COMPONENT.'/lib/controller.php';

class BingTranslateController extends YireoController
{
    /**
     * Display task
     *
     * @access public
     * @param null
     * @return null
     */
	public function display($cachable = false, $urlparams = false)
    {
        JToolBarHelper::preferences('com_bingtranslate', 400, 800);
    }

    /**
     * Translate task
     *
     * @access public
     * @param null
     * @return null
     */
    public function translate()
    {
        // Get the language from request
        $text = JRequest::getVar('text', null, null, null, JREQUEST_ALLOWRAW);
        $toLang = JRequest::getCmd('to');
        $fromLang = JRequest::getCmd('from');

        // Detect JoomFish languages
        if (preg_match('/joomfish([0-9\-]+)/', $toLang)) {

            $languageId = preg_replace('/([^0-9]+)/', '', $toLang);
            $toLang = null;

            $db = JFactory::getDBO();
            $db->setQuery('SELECT * FROM #__languages');
            $languages = $db->loadObjectList();
            if (!empty($languages)) {
                foreach ($languages as $language) {
                    if (isset($language->id) && $language->id == $languageId) {
                        $matchLanguage = $language;
                        break;
                    } else if (isset($language->lang_id) && $language->lang_id == $languageId) {
                        $matchLanguage = $language;
                        break;
                    }
                }

                if (!empty($matchLanguage)) {
                    if (!empty($matchLanguage->lang_code)) {
                        $toLang = $matchLanguage->lang_code; 
                    } else if (!empty($matchLanguage->shortcode)) {
                        $toLang = $matchLanguage->shortcode; 
                    } else if (!empty($matchLanguage->sef)) {
                        $toLang = $matchLanguage->sef; 
                    }
                }
            }
        }

        // Parse the language
        $toLang = preg_replace('/-([a-zA-Z0-9]+)$/', '', $toLang);
        $fromLang = preg_replace('/-([a-zA-Z0-9]+)$/', '', $fromLang);

        // Get the API-key
        $params = JComponentHelper::getParams('com_bingtranslate');
        $client_id = $params->get('client_id');
        $client_secret = $params->get('client_secret');

        // Sanity checks
        if (empty($client_id)) $this->response(JText::_('Windows Azure client-ID is not configured'), false);
        if (empty($client_secret)) $this->response(JText::_('Windows Azure client-secret is not configured'), false);
        if (empty($text)) $this->response(JText::_('No text to translate'), false);

        // Detect the language
        if (empty($fromLang)) {
            $result = $this->getCurlDetect($text);
            if (empty($result)) $this->response(JText::_('No response from Bing'), false);
            if (!preg_match('/^</', $result)) $this->response(JText::_('Not an XML-result'), false);

            // Parse the XML-code
            $xml = new SimpleXMLElement($result);
            if (is_object($xml)) {
                $string = (string)$xml;
                if (!empty($string)) {
                    $fromLang = $string;
                }
            }
        }

        if (empty($fromLang)) $this->response(JText::_('Failed to detect source-language'), false);
        if (empty($toLang)) $this->response(JText::_('Failed to detect destination-language'), false);

        $result = $this->getCurlTranslate($text, $toLang, $fromLang);
        if (empty($result)) $this->response(JText::_('No response from Bing'), false);
        if (!preg_match('/^</', $result)) $this->response(JText::_('Not an XML-result'), false);

        $xml = new SimpleXMLElement($result);
        if (is_object($xml)) {
            $string = (string)$xml;
            if (!empty($string)) {
                $this->response($string);
            }
        }

        $this->response(JText::_('Unknown BingTranslate error: ', $result), false);
    }

    /*
     * Helper method to send a response 
     *
     * @access protected
     * @param string $text
     * @param bool $success
     * @return null
     */
    protected function response($text, $success = true)
    {
        $response = array('text' => $text, 'code' => (int)$success);
        print json_encode($response);
        $application = JFactory::getApplication();
        $application->close();
    }
    
    /**
     * Method to get the access token
     *
     * @access protected
     * @param null
     * @return string
     */
    protected function getAccessToken()
    {
        // If client_id and client_secret empty, return nothing
        $params = JComponentHelper::getParams('com_bingtranslate');
        $client_id = $params->get('client_id');
        $client_secret = $params->get('client_secret');
        if(empty($client_id) || empty($client_secret)) return null;

        // Windows Azure OAuth URL
        $url = 'https://datamarket.accesscontrol.windows.net/v2/OAuth2-13/';

        // Bing API fields
        $fields = array(
            'client_id' => $client_id,
            'client_secret' => $client_secret,
            'scope' => 'http://api.microsofttranslator.com/',
            'grant_type' => 'client_credentials',
        );

        // Make the CURL-call
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
        $result = curl_exec($ch);

        // Empty response
        if(empty($result)) $this->response('Empty response', false);

        // Parse the JSON-data
        $data = json_decode($result);
        if(is_object($data) == false) $this->response('No JSON-object: '.$result, false);

        // Check for errors
        if (isset($data->error)){
            $error = 'Error while requesting OAuth token: '.$data->error;
            if($data->error_description) $error .= ' ['.$data->error_description.']';
            return $this->response($error, false);
        }

        return $data->access_token;
    }

    /*
     * Helper method to get a CURL-response 
     *
     * @access protected
     * @param string $text
     * @return string
     */
    protected function getCurlDetect($text)
    {
        $fields = array(
            'text' => $text,
        );

        return $this->getCurlResponse('Detect', $fields);
    }

    /*
     * Helper method to get a CURL-response 
     * 
     * @access protected
     * @param string $text
     * @param string $toLang
     * @param string $fromLang
     * @return string
     * @link http://msdn.microsoft.com/en-us/library/ff512406.aspx
     */
    protected function getCurlTranslate($text, $toLang, $fromLang)
    {
        $fields = array(
            'text' => $text,
            'to' => $toLang,
            'from' => $fromLang,
            'contentType' => 'text/html',
        );
        return $this->getCurlResponse('Translate', $fields);
    }

    /*
     * Helper method to get a CURL-response 
     *
     * @access protected
     * @param string $task
     * @param array $fields
     * @return string
     */
    protected function getCurlResponse($task, $fields)
    {
        $url = 'http://api.microsofttranslator.com/v2/Http.svc/'.$task;
        $url .= '?'.http_build_query($fields);

        // Add extra Authorization-header
        $accessToken = $this->getAccessToken();

        if(!empty($accessToken)) {
            $headers[] = 'Authorization: Bearer '.$accessToken;
        }

        // Make the CURL-call
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        if(!empty($headers)) curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        return $result;
    }

    /*
     * Helper method to check for Joomla! 1.5
     *
     * @access protected
     * @param null
     * @return bool
     */
    protected function isJoomla15()
    {
        JLoader::import( 'joomla.version' );
        $version = new JVersion();
        if (version_compare( $version->RELEASE, '1.5', 'eq')) {
            return true;
        }
        return false;
    }
}
